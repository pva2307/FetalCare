package com.ejemplo.fetalcare

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.ejemplo.fetalcare.databinding.ActivityHistoryBinding

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lateinit var binding: ActivityHistoryBinding

        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNavigationView.setOnItemReselectedListener { item ->
            val historyIntent = Intent(this, HistoryActivity::class.java)
            val settingsIntent = Intent(this, SettingsActivity::class.java)
            val homeIntent = Intent(this, MainActivity::class.java)
            when (item.itemId) {
                R.id.bottom_home -> {
                    startActivity(homeIntent)
                    finish()
                }

                R.id.bottom_history -> {
                    startActivity(historyIntent)
                    finish()
                }

                R.id.bottom_settings -> {
                    startActivity(settingsIntent)
                    finish()
                }
            }

        }


    }
    
}