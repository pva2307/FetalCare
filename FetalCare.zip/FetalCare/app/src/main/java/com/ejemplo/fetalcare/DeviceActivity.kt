package com.ejemplo.fetalcare

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.ejemplo.fetalcare.databinding.ActivityDeviceBinding
import java.io.IOException
import java.util.UUID
import kotlin.properties.Delegates

class DeviceActivity : AppCompatActivity() {

    lateinit var binding: ActivityDeviceBinding
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private val adapter: BluetoothAdapter? by lazy { BluetoothAdapter.getDefaultAdapter() }
    private var bluetoothGatt: BluetoothGatt? = null
    private val targetDeviceAddress = "C4:DD:57:EB:26:AA"
    private var isConnected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDeviceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backBtn.setOnClickListener {
            val mainIntent = Intent(this, MainActivity::class.java)
            startActivity(mainIntent)
            finish()
        }

        checkBluetoothPermissions()
        isBluetoothNull()
        isBluetoothEnable()
        bluetoothBtn()

        binding.bluetoothBtn.setOnClickListener {
            if (!isBluetoothEnable()) {
                enableBluetooth()
            } else {
                binding.bluetoothBtn.visibility = GONE
            }
        }

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        registerConnectionReceiver()
        checkConnectionStatus()
    }

    private fun isBluetoothNull() {
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null) { //no hay bluetooth
            binding.availableBluetooth.text = "No disponible"
            binding.onBluetooth.visibility = GONE
        } else {
            binding.availableBluetooth.text = "Disponible"
            binding.onBluetooth.visibility = VISIBLE
        }
    }

    private fun isBluetoothEnable(): Boolean {
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        return bluetoothAdapter.isEnabled
    }

    private fun bluetoothBtn() {
        if (isBluetoothEnable()) { //esta encendido
            binding.onBluetooth.text = "Encendido"
            binding.bluetoothBtn.visibility = GONE
            binding.layoutDeviceConnected.visibility = VISIBLE
        } else {
            binding.onBluetooth.text = "Apagado"
            binding.bluetoothBtn.visibility = VISIBLE
            binding.bluetoothBtn.text = "ON"
            binding.layoutDeviceConnected.visibility = GONE
        }
    }

    private val bluetoothStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BLUETOOTH_STATE_CHANGED_ACTION) {
                val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                when (state) {
                    BluetoothAdapter.STATE_ON -> {
                        // El Bluetooth está encendido
                        bluetoothBtn()
                    }

                    BluetoothAdapter.STATE_OFF -> {
                        // El Bluetooth está apagado
                        bluetoothBtn()
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter(BLUETOOTH_STATE_CHANGED_ACTION)
        registerReceiver(bluetoothStateReceiver, filter)
    }

    private fun checkBluetoothPermissions() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_ADMIN
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Permisos de Bluetooth no concedidos, solicita el permiso
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.BLUETOOTH_ADMIN),
                REQUEST_BLUETOOTH_PERMISSION
            )
        }
    }

    private fun enableBluetooth() {
        // El bluetooth esta apagado
        if (!isBluetoothEnable()) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                    REQUEST_BLUETOOTH_PERMISSION
                )
            }
            bluetoothBtn()
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BLUETOOTH)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_BLUETOOTH_PERMISSION) {
            val bluetoothPermiso: Boolean
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                bluetoothPermiso = true
            } else {
                // Permiso de Bluetooth denegado, toma alguna acción si es necesario
                bluetoothPermiso = false
            }
        }
    }

    fun checkConnectionStatus(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                REQUEST_BLUETOOTH_PERMISSION
            )
        }
        val device = adapter?.getRemoteDevice(targetDeviceAddress) ?: return false
        bluetoothGatt = device.connectGatt(this, false, gattCallback)
        return true
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            super.onConnectionStateChange(gatt, status, newState)

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                //Dispositivo conectado
                isConnected = true
                informationUpdate()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                isConnected = false
                informationUpdate()
                // Dispositivo desconectado
            }
        }
    }

    private val connectionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action
            val device = intent?.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)

            if (BluetoothDevice.ACTION_ACL_CONNECTED == action) {
                if (device?.address == targetDeviceAddress) {
                    isConnected = true
                    informationUpdate()
                }
            } else if (BluetoothDevice.ACTION_ACL_DISCONNECTED == action) {
                if (device?.address == targetDeviceAddress) {
                    isConnected = false
                    informationUpdate()
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun informationUpdate() {
        val device = bluetoothGatt?.device
        when {
            isConnected -> {
                binding.tvStatusDevice.text = "Conectado"
                binding.tvNameDevice.visibility = VISIBLE
                binding.tvAddressDevice.visibility = VISIBLE
                device?.let {
                    val deviceName = it.getName()
                    binding.tvNameDevice.text = deviceName ?: "Desconocido"
                    binding.tvAddressDevice.text = it.address
                }
            }
            else -> {
                binding.tvStatusDevice.text = "No conectado"
                binding.tvNameDevice.visibility = GONE
                binding.tvAddressDevice.visibility = GONE
            }
        }
    }

    private fun registerConnectionReceiver() {
        val filter = IntentFilter()
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        registerReceiver(connectionReceiver, filter)
        informationUpdate()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(connectionReceiver)
    }

    companion object {
        const val BLUETOOTH_STATE_CHANGED_ACTION = "android.bluetooth.adapter.action.STATE_CHANGED"
        const val REQUEST_BLUETOOTH_PERMISSION = 1
        private const val REQUEST_ENABLE_BLUETOOTH = 2
    }
}