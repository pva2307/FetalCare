package com.ejemplo.fetalcare

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import com.ejemplo.fetalcare.databinding.ActivityMainBinding
//import com.jjoe64.graphview.series.DataPoint
//import com.jjoe64.graphview.series.LineGraphSeries


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lateinit var binding: ActivityMainBinding

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.dispositivoCard.setOnClickListener {
            val deviceIntent = Intent(this, DeviceActivity::class.java)
            startActivity(deviceIntent)

        }

        binding.fetalHeartCard.setOnClickListener {
            val heartIntent = Intent(this, HeartActivity::class.java)
            startActivity(heartIntent)

        }

        binding.babyCard.setOnClickListener {
            val babyIntent = Intent(this, BabyActivity::class.java)
            startActivity(babyIntent)

        }

        binding.bottomNavigationView.setOnItemReselectedListener { item ->
            val historyIntent = Intent(this, HistoryActivity::class.java)
            val settingsIntent = Intent(this, SettingsActivity::class.java)
            val homeIntent = Intent(this, MainActivity::class.java)
            when (item.itemId) {
                R.id.bottom_home -> {
                    startActivity(homeIntent)
                    finish()
                }

                R.id.bottom_history -> {
                    startActivity(historyIntent)
                    finish()
                }

                R.id.bottom_settings -> {
                    startActivity(settingsIntent)
                    finish()
                }
            }
        }
    }
}