package com.ejemplo.fetalcare

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.ejemplo.fetalcare.databinding.ActivityHeartBinding
import androidx.databinding.DataBindingUtil
import java.io.IOException
import java.io.InputStream
import java.util.UUID

class HeartActivity : AppCompatActivity() {

    lateinit var bluetoothSocket: BluetoothSocket
    lateinit var binding: ActivityHeartBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityHeartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backBtn.setOnClickListener {
            val mainIntent = Intent(this, MainActivity::class.java)
            startActivity(mainIntent)
            finish()
        }
    }
}