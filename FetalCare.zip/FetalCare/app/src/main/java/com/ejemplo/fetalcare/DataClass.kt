package com.ejemplo.fetalcare

data class DataClass(
    var dataName:String, //nombre del dispositivo
    var dataAddress:String //direccion del dispositivo
)

