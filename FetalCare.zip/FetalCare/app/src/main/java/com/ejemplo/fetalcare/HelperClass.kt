package com.ejemplo.fetalcare

class HelperClass(var name: String, var email: String, var password: String) {
    constructor() : this("", "", "")
}