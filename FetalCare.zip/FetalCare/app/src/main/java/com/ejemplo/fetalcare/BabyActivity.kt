package com.ejemplo.fetalcare

import android.content.Intent
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.ejemplo.fetalcare.databinding.ActivityBabyBinding
import com.ejemplo.fetalcare.databinding.DialogDatababyBinding

class BabyActivity : AppCompatActivity() {

    lateinit var binding: ActivityBabyBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityBabyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backBtn.setOnClickListener {
            val mainIntent = Intent(this, MainActivity::class.java)
            startActivity(mainIntent)
            finish()
        }

        binding.editButton.setOnClickListener {
            val dialogBinding = DialogDatababyBinding.inflate(layoutInflater)
            val builder = AlertDialog.Builder(this)
                .setView(dialogBinding.root)
            val dialog = builder.create()

            dialogBinding.btnSave.setOnClickListener {
                val nameBaby = dialogBinding.editBoxName.text.toString()
                val genderBaby = dialogBinding.radioGroupGender.checkedRadioButtonId
                val spinner = dialogBinding.spinnerWeeks
                val weekValues = (1..42).map { it.toString() }

                val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, weekValues)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

                spinner.adapter = adapter

                if (nameBaby.isNotEmpty() && genderBaby != -1) {
                    val gender = if (genderBaby == R.id.radioFemale) "Femenino" else "Masculino"
                    binding.editNameBaby.text = nameBaby
                    binding.editGenderBaby.text = gender
                    spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                            val selectedValue = weekValues[position]
                            binding.editAgeBaby.text = selectedValue
                        }

                        override fun onNothingSelected(parent: AdapterView<*>) {
                            // No se seleccionó ningún valor
                            binding.editAgeBaby.text = weekValues.component1()
                        }
                    }
                } else {
                    Toast.makeText(this, "Ingrese los datos solicitados", Toast.LENGTH_SHORT)
                        .show()
                }
                dialog.dismiss()
            }

            dialogBinding.btnCancel.setOnClickListener {
                dialog.dismiss()
            }

            if (dialog.window != null) {
                dialog.window!!.setBackgroundDrawable(ColorDrawable(0))
            }
            dialog.show()

        }
    }
}