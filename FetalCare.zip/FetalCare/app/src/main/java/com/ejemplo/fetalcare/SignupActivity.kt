package com.ejemplo.fetalcare

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.ejemplo.fetalcare.databinding.ActivitySignupBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class SignupActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var reference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        reference = database.getReference("users")

        binding.signupButton.setOnClickListener {

            val name = binding.name.text.toString()
            val email = binding.signupEmail.text.toString()
            val password = binding.signupPassword.text.toString()
            val confirm = binding.signupConfirm.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty() && confirm.isNotEmpty() && name.isNotEmpty()) {
                if (password == confirm) {
                    val regex =
                        "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&#])[A-Za-z\\d@$!%*?&#]{8,}$".toRegex()
                    if (password.length >= 8 && password.matches(regex)) {
                        if (android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                            firebaseAuth.createUserWithEmailAndPassword(email, password)
                                .addOnSuccessListener { authResult ->

                                    val user = authResult.user
                                    val helperClass = HelperClass(name, email, password)
                                    reference.child(user!!.uid).setValue(helperClass)
                                    user!!.sendEmailVerification()

                                    val intent = Intent(this, LoginActivity::class.java)
                                    Toast.makeText(
                                        this, "Se ha registrado con éxito", Toast.LENGTH_SHORT
                                    ).show()
                                    startActivity(intent)

                                }.addOnFailureListener { exception ->
                                    Toast.makeText(
                                        this, "Error: ${exception.message}", Toast.LENGTH_SHORT
                                    ).show()
                                }
                        } else {
                            Toast.makeText(
                                this, "Ingrese un correo electrónico válido", Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        Toast.makeText(
                            this,
                            "La contraseña debe tener al menos 8 caracteres, una letra mayúscula, una letra minúscula, un número y un carácter especial",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(this, "La contraseña no coincide", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Los espacios no pueden estar vacios", Toast.LENGTH_SHORT)
                    .show()
            }
        }
        binding.loginRedirectText.setOnClickListener {
            val loginIntent = Intent(this, LoginActivity::class.java)
            startActivity(loginIntent)
        }

    }
}